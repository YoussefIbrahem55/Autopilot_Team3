function [lateral_derivatives] = LateralFunc(lateral_data_excel,correction_mat,velocity)

lateral_derivatives(1) =  lateral_data_excel(1) ; 
lateral_derivatives(2) =  lateral_data_excel(2) ; 
lateral_derivatives(3:4) =  inv(correction_mat)*lateral_data_excel(3:4) ; 
lateral_derivatives(5:6) =  inv(correction_mat)*lateral_data_excel(5:6) ; 
lateral_derivatives(7:8) =  inv(correction_mat)*lateral_data_excel(7:8) ; 
lateral_derivatives(9:10) = velocity*lateral_data_excel(9:10);
lateral_derivatives(11:12) =  inv(correction_mat)*lateral_data_excel(11:12) ; 
lateral_derivatives(13:14) =  inv(correction_mat)*lateral_data_excel(13:14) ; 

end