%% clearation 
clear all
close all 
clc
%% problem statement [inputs needed] 
n = 16000       ;            
% number of points starting from 3079 up to inf due to high non linearity
%in this problem
t0 = 0                 ;             % time start 
tf = 25                ;             % time end
dt = (tf-t0)/(n-1)     ;             % step time
t_vec=t0:dt:tf         ;             % vector time specialized for our fun
%initial condition
u_0= 10    ;v_0= 2          ;w_0=0;
p_0=pi/90  ;q_0= pi/180     ;r_0= 0;
phi_0=pi/9 ;theta_0=pi/12   ;epsi_0=pi/6;
x_0=2      ;y_0=4           ;z_0=7;

y_in = [u_0;v_0;w_0;p_0;q_0;r_0;phi_0;theta_0;epsi_0;x_0;y_0;z_0] ;
%% parameters that doesn't appear in workspace because of function (no pointer)
m = 10 ; 
I = [1 -2 -1; -2 5 -4;-1 -4 0.2] ;
force_vector = [8;5;4];
moment_vec = [5;10;20];
%% solution by me
[t_vec_rk4,y_rk4] = rk4_me(@states_dot,t_vec,y_in) ;
%% solution by ode45  [high error] [not compared]
[t_ode45,y_ode45] = ode45(@states_dot,t_vec,y_in);
%% solution by simulink
sim('sim_6_dof_task2.slx')
%% plotting 
%u
f1_x_velocity = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(1,:),'b') 
hold on 
plot (tout,uvw_out(:,1),'r')
legend ('u vel rk4 result','u vel sim result');
title ('comparing between simulink result and rk4 result for velocity in x direction')
xlabel('time(s)');
ylabel('x velocity component(m/s)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(1,:),'*') 
hold on 
plot (tout,uvw_out(:,1),'o')
xlim([5 7]);
legend ('u vel rk4 result','u vel sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('x velocity component(m/s)');
%v
f1_y_velocity = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(2,:),'b') 
hold on 
plot (tout,uvw_out(:,2),'r')
legend ('v vel rk4 result','v vel sim result');
title ('comparing between simulink result and rk4 result for velocity in y direction')
xlabel('time(s)');
ylabel('y velocity component(m/s)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(2,:),'*') 
hold on 
plot (tout,uvw_out(:,2),'o')
xlim([5 7]);
legend ('v vel rk4 result','v vel sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('y velocity component(m/s)');
%w
f1_z_velocity = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(3,:),'b') 
hold on 
plot (tout,uvw_out(:,3),'r')
legend ('w vel rk4 result','w vel sim result');
title ('comparing between simulink result and rk4 result for velocity in z direction')
xlabel('time(s)');
ylabel('z velocity component(m/s)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(3,:),'*') 
hold on 
plot (tout,uvw_out(:,3),'o')
xlim([5 7]);
legend ('w vel rk4 result','w vel sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('w velocity component(m/s)');

%p
f2_p = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(4,:),'b') 
hold on 
plot (tout,anglerates_out(:,1),'r')
legend ('angle rate (p) rk4 result','angle rate (p)sim result');
title ('comparing between simulink result and rk4 result for angle rate p')
xlabel('time(s)');
ylabel('angle rate p(rad/s)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(4,:),'*') 
hold on 
plot (tout,anglerates_out(:,1),'o')
xlim([5 6]);
legend ('angle rate (p) rk4 result','angle rate (p) sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('angle rate p(rad/s)');
%q
f2_q = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(5,:),'b') 
hold on 
plot (tout,anglerates_out(:,2),'r')
legend ('angle rate (q) rk4 result','angle rate (q)sim result');
title ('comparing between simulink result and rk4 result for angle rate q')
xlabel('time(s)');
ylabel('angle rate q(rad/s)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(5,:),'*') 
hold on 
plot (tout,anglerates_out(:,2),'o')
xlim([5 6]);
legend ('angle rate (q) rk4 result','angle rate (q) sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('angle rate q(rad/s)');
%r
f2_r = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(6,:),'b') 
hold on 
plot (tout,anglerates_out(:,3),'r')
legend ('angle rate (r) rk4 result','angle rate (r)sim result');
title ('comparing between simulink result and rk4 result for angle rate r')
xlabel('time(s)');
ylabel('angle rate r(rad/s)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(6,:),'*') 
hold on 
plot (tout,anglerates_out(:,3),'o')
xlim([5 6]);
legend ('angle rate (r) rk4 result','angle rate (r) sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('angle rate r(rad/s)');

y_rk4(7:9,:) =wrapToPi(y_rk4(7:9,:)) ; 
%phi(degree)
f3_phi = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(7,:)*(180/pi),'b') 
hold on 
plot (tout,angles_out(:,1)*(180/pi),'r')
legend ('phi euler angle rk4 result','phi euler angle sim result');
title ('comparing between simulink result and rk4 result for phi')
xlabel('time(s)');
ylabel('angle phi(degree)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(7,:)*(180/pi),'*') 
hold on 
plot (tout,angles_out(:,1)*(180/pi),'o')
xlim([5 6]);
legend ('phi euler angle rk4 result','phi euler angle sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('angle phi(degree)');

%theta(degree)
f3_theta = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(8,:)*(180/pi),'b') 
hold on 
plot (tout,angles_out(:,2)*(180/pi),'r')
legend ('theta euler angle rk4 result','theta euler angle sim result');
title ('comparing between simulink result and rk4 result for theta')
xlabel('time(s)');
ylabel('angle theta(degree)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(8,:)*(180/pi),'*') 
hold on 
plot (tout,angles_out(:,2)*(180/pi),'o')
xlim([5 6]);
legend ('theta euler angle rk4 result','theta euler angle sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('angle theta(degree)');
%epsi(degree)
f3_epsi = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(9,:)*(180/pi),'b') 
hold on 
plot (tout,angles_out(:,3)*(180/pi),'r')
legend ('epsi euler angle rk4 result','epsi euler angle sim result');
title ('comparing between simulink result and rk4 result for epsi')
xlabel('time(s)');
ylabel('angle epsi(degree)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(9,:)*(180/pi),'*') 
hold on 
plot (tout,angles_out(:,3)*(180/pi),'o')
xlim([5 6]);
legend ('epsi euler angle rk4 result','epsi euler angle sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('angle epsi(degree)');

%x_pos
f4_x_pos = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(10,:),'b') 
hold on 
plot (tout,xyz_out(:,1),'r')
legend ('x position rk4 result','x position sim result');
title ('comparing between simulink result and rk4 result for x position')
xlabel('time(s)');
ylabel('x position(m)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(10,:),'*') 
hold on 
plot (tout,xyz_out(:,1),'o')
xlim([5 5.2]);
legend ('x position rk4 result','x position sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('x position(m)');
%y_pos
f4_y_pos = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(11,:),'b') 
hold on 
plot (tout,xyz_out(:,2),'r')
legend ('y position rk4 result','y position sim result');
title ('comparing between simulink result and rk4 result for y position')
xlabel('time(s)');
ylabel('y position(m)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(11,:),'*') 
hold on 
plot (tout,xyz_out(:,2),'o')
xlim([5 5.2]);
legend ('y position rk4 result','y position sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('y position(m)');
%z_pos
f4_z_pos = figure
grid on 
subplot(2,1,1);
plot (t_vec_rk4,y_rk4(12,:),'b') 
hold on 
plot (tout,xyz_out(:,3),'r')
legend ('z position rk4 result','z position sim result');
title ('comparing between simulink result and rk4 result for z position')
xlabel('time(s)');
ylabel('z position(m)');

subplot(2,1,2);
plot (t_vec_rk4,y_rk4(12,:),'*') 
hold on 
plot (tout,xyz_out(:,3),'o')
xlim([5 5.2]);
legend ('z position rk4 result','z position sim result');
title ('comparing with zooming on special location')
xlabel('time(s)');
ylabel('z position(m)');

%% values of the errors using a combination of method [bouns] 

% method 1 MAE(Mean absolute error) [wikipidea]

e_state1 =  sum(abs(y_rk4(1,:)-uvw_out(:,1)'))/n ;
e_state2 =  sum(abs(y_rk4(2,:)-uvw_out(:,2)'))/n ;
e_state3 =  sum(abs(y_rk4(3,:)-uvw_out(:,3)'))/n ;
e_state4 =  sum(abs(y_rk4(4,:)-anglerates_out(:,1)'))/n ;
e_state5 =  sum(abs(y_rk4(5,:)-anglerates_out(:,2)'))/n ;
e_state6 =  sum(abs(y_rk4(6,:)-anglerates_out(:,3)'))/n ;
e_state7 =  sum(abs(y_rk4(7,:)-angles_out(:,1)'))/n;
e_state8 =  sum(abs(y_rk4(8,:)-angles_out(:,2)'))/n;
e_state9 =  sum(abs(y_rk4(9,:)-angles_out(:,3)'))/n;
e_state10 = sum(abs(y_rk4(10,:)-xyz_out(:,1)'))/n;
e_state11 = sum(abs(y_rk4(11,:)-xyz_out(:,2)'))/n;
e_state12 = sum(abs(y_rk4(12,:)-xyz_out(:,3)'))/n;
method1_MAE_error = [e_state1 e_state2 e_state3;
                 e_state4 e_state5 e_state6;
                 e_state7 e_state8 e_state9;
                 e_state10 e_state11 e_state12] 
             
%method 2 MAPE(Mean absolute percentage error) [wiki] 
%percentage of the error
e_state1 =  sum(abs((y_rk4(1,:)-uvw_out(:,1)')./uvw_out(:,1)'))/n ;
e_state2 =  sum(abs((y_rk4(2,:)-uvw_out(:,2)')./uvw_out(:,2)'))/n ;
e_state3 =  sum(abs((y_rk4(3,:)-uvw_out(:,3)')./uvw_out(:,3)'))/n ;
e_state4 =  sum(abs((y_rk4(4,:)-anglerates_out(:,1)')./anglerates_out(:,1)'))/n ;
e_state5 =  sum(abs((y_rk4(5,:)-anglerates_out(:,2)')./anglerates_out(:,2)'))/n ;
e_state6 =  sum(abs((y_rk4(6,:)-anglerates_out(:,3)')./anglerates_out(:,3)'))/n ;
e_state7 =  sum(abs((y_rk4(7,:)-angles_out(:,1)')./angles_out(:,1)'))/n;
e_state8 =  sum(abs((y_rk4(8,:)-angles_out(:,2)')./angles_out(:,2)'))/n;
e_state9 =  sum(abs((y_rk4(9,:)-angles_out(:,3)')./angles_out(:,3)'))/n;
e_state10 = sum(abs((y_rk4(10,:)-xyz_out(:,1)')./angles_out(:,1)'))/n;
e_state11 = sum(abs((y_rk4(11,:)-xyz_out(:,2)')./angles_out(:,2)'))/n;
e_state12 = sum(abs((y_rk4(12,:)-xyz_out(:,3)')./angles_out(:,3)'))/n;
method2_MAPE_error = [e_state1 e_state2 e_state3;
                 e_state4 e_state5 e_state6;
                 e_state7 e_state8 e_state9;
                 e_state10 e_state11 e_state12] 
%method 3 MSE(Mean squared error) [wiki] 
e_state1 =  sum((y_rk4(1,:)-uvw_out(:,1)').^2)/n ;
e_state2 =  sum((y_rk4(2,:)-uvw_out(:,2)').^2)/n ;
e_state3 =  sum((y_rk4(3,:)-uvw_out(:,3)').^2)/n ;
e_state4 =  sum((y_rk4(4,:)-anglerates_out(:,1)').^2)/n ;
e_state5 =  sum((y_rk4(5,:)-anglerates_out(:,2)').^2)/n ;
e_state6 =  sum((y_rk4(6,:)-anglerates_out(:,3)').^2)/n ;
e_state7 =  sum((y_rk4(7,:)-angles_out(:,1)').^2)/n;
e_state8 =  sum((y_rk4(8,:)-angles_out(:,2)').^2)/n;
e_state9 =  sum((y_rk4(9,:)-angles_out(:,3)').^2)/n;
e_state10 = sum((y_rk4(10,:)-xyz_out(:,1)').^2)/n;
e_state11 = sum((y_rk4(11,:)-xyz_out(:,2)').^2)/n;
e_state12 = sum((y_rk4(12,:)-xyz_out(:,3)').^2)/n;
method3_MSE_error = [e_state1 e_state2 e_state3;
                 e_state4 e_state5 e_state6;
                 e_state7 e_state8 e_state9;
                 e_state10 e_state11 e_state12] 
%% added sec
% fc_p = figure
% grid on 
% plot (t_vec_rk4,(y_rk4(9,:)),'b') 
% hold on 
% plot (t_vec,wrapToPi(y_ode45(:,9)),'r')