% the aerodynamic forces and moments can be expressed as a function of all the motion variables [Nelson] page 63
 clc
 clear all
 close all
%  Excel Sheets Data
% global aircraft_derivatives_dimensions 

%filename_density_L = 'B747_FC5'; %%put here the location of your excel sheet
filename_density_L = 'NT_33A_FC_6'; %%put here the location of your excel sheet

aircraft_data=xlsread(filename_density_L,'B2:B61');%% here B2:B61 means read the excel sheet from cell B2 to cell B61

%%in the next step we will read from the vector(aircraft_data) but take care of the order the values in excel sheet is arranged

% Time vector parameters
dt = aircraft_data(1);    tfinal = aircraft_data(2); lengths=tfinal/dt+1;
time_V = (0:dt:tfinal)';

% initial conditions (equilibrium point around it we make the linearization)
s0 = aircraft_data(4:15);
sdot0 = zeros(12,1);
Vto = sqrt(s0(1)^2 + s0(2)^2 + s0(3)^2);    % Vto
alpha0 = atan(s0(3)/s0(1));
beta0 = asin(s0(2)/Vto) ;
% control actions values
% da = aircraft_data(57);
% dr = aircraft_data(58);
% de = aircraft_data(59);
% dth = aircraft_data(60);
dc = [ aircraft_data(57:59) * pi/180 ; aircraft_data(60)];

% gravity, mass % inertia
m = aircraft_data(51);
g = aircraft_data(52);
Ixx = aircraft_data(53);
Iyy = aircraft_data(54);
Izz = aircraft_data(55);
Ixz = aircraft_data(56);    Ixy=0;  Iyz=0;
I = [Ixx , -Ixy , -Ixz ;...
    -Ixy , Iyy , -Iyz ;...
    -Ixz , -Iyz , Izz];
invI=inv(I);

% stability derivatives Longitudinal motion
SD_Long = aircraft_data(21:36);
SD_Long_final = SD_Long;
tempvarlong = num2cell(SD_Long_final) ;
[Xu,Zu,Mu,Xw,Zw,Mw,Zwd,Zq,Mwd,Mq,Xde,Zde,Mde,Xdth,Zdth,Mdth] = deal(tempvarlong{:});
 clear tempvarlong;
% stability derivatives Lateral motion
SD_Lat_dash = aircraft_data(37:50);
G = 1/(1-(Ixz*Ixz/(Ixx*Izz)));
correction_matrix = [G G*Ixz/Ixx;G*Ixz/Izz G];
% run('LateralFunc')
SD_Lat_final =  LateralFunc(SD_Lat_dash,correction_matrix,Vto);
tempvarlat = num2cell(SD_Lat_final) ; 
[Yv,Yb,Lb,Nb,Lp,Np,Lr,Nr,Yda,Ydr,Lda,Nda,Ldr,Ndr]= deal(tempvarlat{:});
clear tempvarlat;

Lv = Lb/Vto ;
Nv = Nb/Vto ;  
Yp = 0 ;
Yr = 0 ; 
% initial gravity force
mg0 = m*g * [ sin(s0(8)) ; -cos(s0(8))*sin(s0(7)) ; -cos(s0(8))*cos(s0(7)) ];
M0 = [0 0 0] ;
%% matrices neede for simulink
states_mat  =[Xu 0 Xw 0 0 0 0 0 0 0 0 0 0;
              0 Yv 0 Yp 0 Yr 0 0 0 0 0 0 0;
              Zu 0 Zw 0 Zq 0 0 0 0 0 0 0 Zwd;
              0 Lv 0 Lp 0 Lr 0 0 0 0 0 0 0;
              Mu 0 Mw 0 Mq 0 0 0 0 0 0 0 Mwd;
              0 Nv 0 Np 0 Nr 0 0 0 0 0 0 0] ;
          % delta states+wdot from Ab in simulink   
controls_mat=  [0 Xde Xdth 0;
                0 0 0 Ydr;
                0 Zde Zdth 0;
                Lda 0 0 Ldr;
                0 Mde Mdth 0;
                Nda 0 0 Ndr];
%%
sim('sim_airplane_task3')
%% plotting
figure
plot3(X,Y,Z);
title('Trajectory')

figure
subplot(4,3,1)
plot(time_V,u)
title('u (ft/sec)')
xlabel('time (sec)')

subplot(4,3,2)
%plot(time_V,v)
%title('v (ft/sec)')
plot(time_V,unwrap(beta))
title('beta (degree)')
xlabel('time (sec)')

subplot(4,3,3)
% plot(time_V,w)
% title('w (ft/sec)')
plot(time_V,unwrap(alpha))
title('alpha (degree)')
xlabel('time (sec)')

subplot(4,3,4)
plot(time_V,p)
title('p (deg/sec)')
xlabel('time (sec)')

subplot(4,3,5)
plot(time_V,q)
title('q (deg/sec)')
xlabel('time (sec)')

subplot(4,3,6)
plot(time_V,r)
title('r (deg/sec)')
xlabel('time (sec)')

subplot(4,3,7)
plot(time_V,unwrap(phi))
title('\phi (deg)')
xlabel('time (sec)')

subplot(4,3,8)
plot(time_V,unwrap(theta))
title('\theta (deg)')
xlabel('time (sec)')

subplot(4,3,9)
plot(time_V,unwrap(psi))
title('\psi (deg)')
xlabel('time (sec)')

subplot(4,3,10)
plot(time_V,X)
title('x (ft)')
xlabel('time (sec)')

subplot(4,3,11)
plot(time_V,Y)
title('y (ft)')
xlabel('time (sec)')

subplot(4,3,12)
plot(time_V,Z)
title('z (ft)')
xlabel('time (sec)')
