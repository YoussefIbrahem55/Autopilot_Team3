%% states function (task2)  

function [states_vector_dot] = states_dot(t,state_initial,mass,i_mat)
%% calculating and updating the forces and moments (mass and inertia)
m = 10 ; 
I = [1 -2 -1; -2 5 -4;-1 -4 0.2] ;
%..................................................%      
force_vector = [8;5;4];
moment_vec = [5;10;20];
%...................................................%
u=state_initial(1)  ;v=state_initial(2)      ;w=state_initial(3);
p=state_initial(4)  ;q=state_initial(5)      ;r=state_initial(6);
phi=state_initial(7);theta=state_initial(8);epsi=state_initial(9);
x=state_initial(10) ;y=state_initial(11)    ;z=state_initial(12);

%% matrix needed 
j_11=1 ;j_12=sin(phi)*tan(theta);j_13=cos(phi)*tan(theta);
j_21=0 ;j_22=cos(phi);           j_23=-sin(phi);
j_31=0 ;j_32=sin(phi)/cos(theta);j_33=cos(phi)/cos(theta);
j_tr=[j_11 j_12 j_13;
      j_21 j_22 j_23;
      j_31 j_32 j_33] ;     %first transformation matrix of kinematics

T_eb11= cos(theta)*cos(epsi); 
T_eb12=-cos(phi)*sin(epsi)+sin(phi)*sin(theta)*cos(epsi);
T_eb13=sin(phi)*sin(epsi)+cos(phi)*sin(theta)*cos(epsi) ;
T_eb21=cos(theta)*sin(epsi);
T_eb22=cos(phi)*cos(epsi)+sin(phi)*sin(theta)*sin(epsi);
T_eb23=-sin(phi)*cos(epsi)+cos(phi)*sin(theta)*sin(epsi);
T_eb31=-sin(theta);
T_eb32= sin(phi)*cos(theta);
T_eb33 = cos(phi)*cos(theta);
T_eb = [T_eb11 T_eb12 T_eb13;
        T_eb21 T_eb22 T_eb23;
        T_eb31 T_eb32 T_eb33] ; %Euler matrix of kinematics
%% to check (replace T_eb with T_EB in dots calculations ) 
euler_ang= [phi theta epsi];
T_EB = eul2rotm(euler_ang) ; 
%% dots calcualtions 
%velocity dots vector
states_vector_dot(1:3,1)  = (1/m)*force_vector-cross([p;q;r],[u;v;w])   ;
%angular velocity dots vector
states_vector_dot(4:6,1)  =inv(I)*[moment_vec-cross([p;q;r],I*[p;q;r])] ; 
%eular angles_dot vector
states_vector_dot(7:9,1)  = j_tr*[p;q;r];
%distance dot vector
states_vector_dot(10:12,1)= T_eb *[u;v;w];

end