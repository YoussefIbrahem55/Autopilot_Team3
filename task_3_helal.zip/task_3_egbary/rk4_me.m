%% function_rk4 
function [t,y_mat]=rk4_me(func,t_vec,i_c)
y_mat(:,1)= i_c ; 
size_of_time = size(t_vec) ; 
                if (size_of_time(2)==2) 
                    N = 100 ;
                    delta_t = (t_vec(2)-t_vec(1))/(N-1) ;
                    t_vec =t_vec(1):delta_t:t_vec(2) ;
                else 
                    N = size_of_time(2) ;
                    delta_t = t_vec(2)-t_vec(1) ; 
                end
t = t_vec ;
for  i=1:1:N-1
    
k1 = func(t_vec(i),y_mat(:,i)) ;
k2 = func(t_vec(i)+0.5*delta_t,y_mat(:,i)+0.5*delta_t*k1) ;
k3 = func(t_vec(i)+0.5*delta_t,y_mat(:,i)+0.5*delta_t*k2) ;
k4 = func(t_vec(i)+delta_t,y_mat(:,i)+delta_t*k3) ;

y_mat(:,i+1) = y_mat(:,i)+delta_t*(1/6)*(k1+2*k2+2*k3+k4) ;
end


end